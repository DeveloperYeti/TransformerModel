'''
    한국어AI 경진대회 2023 제출 코드 입출력 예시
'''

import argparse
import json
import os
import soundfile as sf
import numpy as np
import sys

def arg_parse():
    parser = argparse.ArgumentParser(description='Korean SR Contest 2023')
    parser.add_argument('--audiolist', type=str)
    parser.add_argument('--outfile', type=str)

    args = parser.parse_args()

    


    return args


'''
    - file_list : audio file list (pcmlist.txt)
    - out_file : output file (Q3.json)
'''

def clip_detected(audio_data, sample_rate):
    """
    audio_data(오디오파일 객체) 와 sample_rate(샘플레이트 객체)를 받아 클리핑 여부 검사
    """
    threshold = 0.9
    clipping_indices = [i for i, amplitude in enumerate(
        audio_data) if abs(amplitude) > threshold]
    return len(clipping_indices) > 0


def zero_data (audio_data,sample_rate):
    audio_data_sqr = audio_data ** 2
    cumulative_audio_data = np.cumsum(audio_data_sqr)
    sum_cumulative_audio_data = np.sum(cumulative_audio_data)
    return sum_cumulative_audio_data <= 160


def detect_wav_error(file_list, out_file):
    current_directory = os.path.dirname(
        os.path.realpath(__file__))  # 현재 내 작업 경로 불러오기
    file_list_path = os.path.join(current_directory, file_list)  # 텍스트 파일 경로 지정
    out_file_path = os.path.join(current_directory, out_file)  # json파일 경로 지정
    errorlist = {"error_list": []}  # 에러 리스트 json 파일로 기본 지정
    with open(file_list_path, 'r', encoding="utf-8")as txt_file:
        files = [file.strip() for file in txt_file.readlines()]  # 텍스트 파일 읽어서 파일 리스트및 경로 불러오기
    for file_path in files:  # 리스트로 한개씩 읽어서 파일 읽기
        # 파일 절대경로로 지정후 다듬기(이과정 없으면 ..\\..\\가 상대경로가 아닌 그대로 경로명이 되어버림)
        abs_file_path = os.path.normpath(os.path.join(current_directory, file_path))
        #abs_file_path="C:\\Users\\AI509-08\\Downloads\\data-main\\data-main\\문제1\\output\\task1_03.wav"#클리핑 확인용 예비 파일
        try:
            audio_data, sample_rate = sf.read(abs_file_path)
            clip_detected(audio_data,sample_rate)
            if len(audio_data) <= 0:  # 만약 오디오의 길이가 0보다 작으면
                raise Exception("기본 데이터 없음")  # 데이터 없음 오류
            # 이외의 경우 clip_detected(abs_file_path)함수를 이용해 데이터 클리핑체크
            elif clip_detected(audio_data, sample_rate):
                raise Exception("데이터 클리핑")
            elif zero_data(audio_data,sample_rate):
                raise  Exception("데이터 없음")
            # accum (autio_data ^ 2)  16000 * 30
        except Exception as e:
            errorlist["error_list"].append(file_path)
            print(e)
    with open(out_file_path, 'w', encoding="utf-8") as json_file:
        json.dump(errorlist, json_file, ensure_ascii=False, indent=4)
    json_name = os.path.basename(json_file.name)
    print(f"{json_name}생성 완료")

                
    




def main():
    if "--audiolist" not in sys.argv[1] or "--outfile" not in sys.argv[2]:
        arg1 = sys.argv[1].replace("--audiolist=", "")
        arg2 = sys.argv[2].replace("--outfile=", "")
        detect_wav_error(arg1, arg2)
    else:
        args = arg_parse()
        detect_wav_error(args.audiolist, args.outfile)
    

    


if __name__ == "__main__":
    main()