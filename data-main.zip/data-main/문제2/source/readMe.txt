# 문제2. 에러 음성파일 찾기

1. requirements.txt
	pydub
	json
	tqdm
	numpy
	soundfile
	os


2. how to start
   python3 Q2.py --audiolist=wavlist.txt --outfile=../output/Q2.json
