def make_wav_format(pcm_data:bytes, ch:int) -> bytes:
        waves = []
        waves.append(struct.pack('<4s', b'RIFF'))
        waves.append(struct.pack('I', 1))  
        waves.append(struct.pack('4s', b'WAVE'))
        waves.append(struct.pack('4s', b'fmt '))
        waves.append(struct.pack('I', 16))
        # audio_format, channel_cnt, sample_rate, bytes_rate(sr*blockalign:초당 바이츠수), block_align, bps
        if ch == 2:
            waves.append(struct.pack('HHIIHH', 1, 2, 16000, 64000, 4, 16))  
        else:
            waves.append(struct.pack('HHIIHH', 1, 1, 16000, 32000, 2, 16))
        waves.append(struct.pack('<4s', b'data'))
        waves.append(struct.pack('I', len(pcm_data)))
        waves.append(pcm_data)
        waves[1] = struct.pack('I', sum(len(w) for w in waves[2:]))
        return b''.join(waves)

import struct
import pathlib
mypath ="C:\\Users\\AI509-08\\Downloads\\data-main\\data-main\\data\\문제3\\"

for i in range(1,6):
     playlist = f"task3_03"
     print(playlist)
     pcm_bytes = pathlib.Path(mypath+playlist+".pcm").read_bytes()
     wav_bytes = make_wav_format(pcm_bytes, 1)
     with open("task3_03"+".wav", 'wb') as file:
        file.write(wav_bytes)