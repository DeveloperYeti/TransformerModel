import librosa
import librosa.display
import numpy as np
import os
import matplotlib.pyplot as plt
def detect_silence():

    pcm_file_path = "\\task3_01.pcm"
    current_directory = os.path.dirname(os.path.realpath(__file__))
    rootpath = os.path.normpath(os.path.join(current_directory,"..\\..\\data\\문제3"))

    # 오디오 파일 로드
    with open(rootpath+pcm_file_path, 'rb') as f:
        pcm_data = np.fromfile(f, dtype=np.int16)
    sample_rate = 16000.0
    spectrum = np.fft.fft(pcm_data)
    magnitude_spectrum = np.abs(spectrum)
    dB_spectrum = 20 * np.log10(magnitude_spectrum / np.max(magnitude_spectrum))
    t = np.linspace(0, len(pcm_data) / sample_rate, len(pcm_data), endpoint=False)
    plt.figure()
    plt.subplot(2, 1, 1)
    plt.plot(pcm_data, 'b-', label='Input Signal')
    plt.title('Input Signal')
    plt.subplot(2, 1, 2)
    plt.xlabel('Time [s]')
    plt.show()

    # 스펙트로그램 플롯

detect_silence()