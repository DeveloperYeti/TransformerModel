# 문제3. 무음 구간 찾기

1. requirements.txt
	pydub
	json
	tqdm

2. how to start
   python3 Q3.py pcmlist.txt ../output/Q3.json
