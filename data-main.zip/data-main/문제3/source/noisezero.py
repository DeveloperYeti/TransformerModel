import numpy as np
from scipy.io import wavfile
import matplotlib.pyplot as plt
import soundfile as sf
import os
import json
import scipy.signal as signal


def outjson(data,out_file):
    """
    data 에는 json 구조를, out file 에는 경로를 지정
    """
    with open(out_file, 'r') as js:
        nowjson = json.load(js)
    # 데이터 추가
    nowjson.update(data)

    # 새로운 JSON 파일에 데이터 저장
    with open(out_file, 'w') as js:
        json.dump(nowjson, js, indent=4)
# WAV 파일 경로 지정
wav_file_path = "\\task3_02.pcm"
current_directory = os.path.dirname(os.path.realpath(__file__))
rootpath = os.path.normpath(os.path.join(current_directory,"..\\..\\data\\문제3"))

# WAV 파일 로드
#sample_rate, audio_data = wavfile.read(rootpath+wav_file_path)
with open(rootpath+wav_file_path,'rb') as pcm:
    pcm_data = pcm.read()
    audio_data = np.frombuffer(pcm_data, dtype=np.int16)
    

# 입력 신호 생성
fs = 16000  # 샘플링 주파수 (Hz)
t = np.linspace(0, len(audio_data) / fs, len(audio_data), endpoint=False)  # 1초 동안의 시간 배열 생성
time = np.arange(len(audio_data))  / fs # 시간

# 주파수 대역 통과 필터 설계
lowcut = 400.0  # 주파수\대역 통과 필터의 저주파수 경계 (Hz)
highcut = 500.0  # 주파수 대역 통과 필터의 고주파수 경계 (Hz)
nyquist = 0.5 * fs
low = lowcut / nyquist
high = highcut / nyquist
b, a = signal.butter(2, [low, high], btype='band')

# 주파수 대역 통과 필터를 신호에 적용

#output_signal = signal.lfilter(b, a, audio_data)
output_signal = signal.filtfilt(b, a, audio_data)

output_signal_abs = np.abs(output_signal)

out_avg = np.mean(output_signal_abs)
np_out_avg = np.full(len(output_signal_abs),out_avg)
output_signal_abs_out_avg = output_signal_abs-(out_avg*1.2)#절대값 output_signal - 평균값
output_signal_abs_out_avg = [x if x > out_avg else 0 for x in output_signal_abs_out_avg]

timeList = []
beforeIdx = 0
for i,x in enumerate(output_signal_abs_out_avg):
    if len(timeList) == 0:
        if x == 0:
            timeList.append(i)
    else:
        if x == 0 and beforeIdx+1 != i:
            if i - timeList[-1] >= 16000 * 4:
                print(timeList[-1]/16000 + 0.1, ",", i/16000 - 0.1)
            timeList.append(i)
            
    if x == 0:
        beforeIdx = i    

plt.figure()
plt.plot(timeList)
plt.show()



# 결과를 그래프로 표시
plt.figure()
plt.subplot(2, 1, 1)
plt.plot(time,audio_data, 'g-', label='abs')
plt.plot(time,np_out_avg,label='out_avg', color='red')
plt.title('output abs')
plt.subplot(2, 1, 2)
plt.plot(time,output_signal_abs_out_avg, 'g-', label='Output Signal')
plt.plot(time,np_out_avg,label='out_avg', color='red')
plt.legend()
plt.title('Output Signal (After Bandpass Filtering)')
plt.xlabel('Time [s]')
plt.tight_layout()
plt.show()
