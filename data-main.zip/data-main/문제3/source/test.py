import json
import os
import soundfile as sf
import numpy as np
import matplotlib.pyplot as plt
threshold_dB = -30.0
sample_rate = 16000 #공식 홈페이지의 16 kHz
channels = 1  #공식 홈페이지의 mono 채널에 따름

def detect_silence(file_list, out_file):
    current_directory = os.path.dirname(os.path.realpath(__file__)) #현재 내 작업 경로 불러오기
    with open(file_list,'r',encoding="utf-8")as txt_file:
        files = [file.strip() for file in txt_file.readlines()] # 텍스트 파일 읽어서 파일 리스트및 경로 불러오기
    for file_path in files:#리스트로 한개씩 읽어서 파일 읽기
        abs_file_path=os.path.normpath(os.path.join(current_directory,file_path))
        with open(abs_file_path, "rb") as pcm_file:#pcm 파일을 바이트코드로 읽고
            audio_np = np.fromfile(pcm_file, dtype=np.int16)
            #audio_data = np.frombuffer(audio_np, dtype=np.int16)

            time_interval = 1.0 / 16000

            # 시간 배열 생성
            time = np.arange(0, len(audio_np)) * time_interval

            # 데시벨 값을 계산합니다.
            db_values = []
            window_size = 160  # 이 값을 조절하여 데시벨 값의 평균을 계산할 시간 윈도우 크기를 조절할 수 있습니다.
            for i in range(0, len(audio_np), window_size):
                window = audio_np[i:i + window_size]
                rms = np.sqrt(np.mean(np.square(window)))
                # RMS 값을 데시벨로 변환합니다.
                db = 20 * np.log10(rms)
                db_values.append(db)



            plt.figure()
            plt.plot(db_values)
            plt.show()
            '''
            time = [i / sample_rate for i in range(len(audio_np))]
            plt.figure(figsize=(10, 4))
            plt.plot(time, rms, label='오디오 데이터')
            plt.xlabel('시간 (초)')
            plt.ylabel('진폭')
            plt.title('오디오 파일')
            plt.legend()
            plt.grid(True)
            plt.show()

            time = [i / sample_rate for i in range(len(audio_np))]
            plt.figure(figsize=(10, 4))
            plt.plot(time, audio_np, label='오디오 데이터')
            plt.xlabel('시간 (초)')
            plt.ylabel('진폭')
            plt.title('오디오 파일')
            plt.legend()
            plt.grid(True)
            plt.show()
            '''


            """
            pcm_data = np.fromf.ile(pcm_file, dtype=np.int16)#해당 파일을 16비트의 넘파이 배열로 받음, 이유는 pcm 데이터를 넘파이 배열로 받으면 음성의 규모가 커져, 최대크기 -32,768에서 32,767 까지 표현 가능한 int16으로 받음
            pcm_data = pcm_data.reshape(-1, channels)
            amplitude_dB = 20 * np.log10(np.abs(pcm_data))
            silence_indices = np.where(amplitude_dB < threshold_dB)[0]
            print(silence_indices)
            time_in_seconds = 1 / sample_rate
            print(time_in_seconds * 812)
            print(silence_indices[0])
            """


current_directory = os.path.dirname(os.path.realpath(__file__))
pcm_list=os.path.join(current_directory,"pcmlist.txt")
Q3_json=os.path.normpath(os.path.join(current_directory,"..\\..\\output\\Q3.json"))
detect_silence(pcm_list , Q3_json)

