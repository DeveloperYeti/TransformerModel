'''
    한국어AI 경진대회 2023 제출 코드 입출력 예시
'''

import argparse
import numpy as np
from scipy.io import wavfile
import soundfile as sf
import os
import json
import scipy.signal as signal
import sys

def save_json(reslut,out_file_path):
    formatted_data = "{\n"
    for key, value in reslut.items():
        formatted_data += f'    "{key}": [\n'
        for item in value:
            formatted_data += f'        {json.dumps(item, ensure_ascii=False)},\n'
        formatted_data = formatted_data.rstrip(',\n')  # 마지막 쉼표와 개행 문자 제거
        formatted_data += '\n    ],\n'

    formatted_data = formatted_data.rstrip(',\n')  # 마지막 쉼표와 개행 문자 제거
    formatted_data += "\n}"
    with open(out_file_path, 'w', encoding="utf-8") as json_file:
        json_file.write(formatted_data)
    json_name = os.path.basename(json_file.name)
    print(f"{json_name}생성 완료")

def arg_parse():
    parser = argparse.ArgumentParser(description='Korean SR Contest 2023')
    parser.add_argument('--audiolist', type=str)
    parser.add_argument('--outfile', type=str)

    args = parser.parse_args()

    return args


'''
    - file_list : audio file list (pcmlist.txt)
    - out_file : output file (Q3.json)
'''

def detect_silence(file_list, out_file):
    reslut = {}   
    current_directory = os.path.dirname(os.path.realpath(__file__))  # 현재 내 작업 경로 불러오기
    file_list_path = os.path.join(current_directory, file_list)  # 텍스트 파일 경로 지정
    out_file_path =os.path.normpath(os.path.join(current_directory, out_file))  # json파일 경로 지정
    with open(file_list_path, 'r', encoding="utf-8")as txt_file:
            files = [file.strip() for file in txt_file.readlines()]  # 텍스트 파일 읽어서 파일 리스트및 경로 불러오기
    for file_path in files:  # 리스트로 한개씩 읽어서 파일 읽기
        abs_file_path = os.path.normpath(os.path.join(current_directory, file_path))
        with open(abs_file_path,'rb') as pcm:
            pcm_data = pcm.read()
            pcm_name = os.path.basename(pcm.name)
        print(f"{pcm_name}파일 읽기 성공")
        audio_data = np.frombuffer(pcm_data, dtype=np.int16)
        fs = 16000  # 샘플링 주파수 (Hz)
        # 주파수 대역 통과 필터 설계
        lowcut = 400.0  # 주파수\대역 통과 필터의 저주파수 경계 (Hz)
        highcut = 500.0  # 주파수 대역 통과 필터의 고주파수 경계 (Hz)
        nyquist = 0.5 * fs
        low = lowcut / nyquist
        high = highcut / nyquist
        b, a = signal.butter(2, [low, high], btype='band')
        # 주파수 대역 통과 필터를 신호에 적용
        #output_signal = signal.lfilter(b, a, audio_data)
        output_signal = signal.filtfilt(b, a, audio_data)
        output_signal_abs = np.abs(output_signal)
        out_avg = np.mean(output_signal_abs)
        np_out_avg = np.full(len(output_signal_abs),out_avg)
        output_signal_abs_out_avg = output_signal_abs-(out_avg*1.2)#절대값 output_signal - 평균값
        output_signal_abs_out_avg = [x if x > out_avg else 0 for x in output_signal_abs_out_avg]

        timeList = []
        beforeIdx = 0
        reslut[pcm_name] =[]
        for i,x in enumerate(output_signal_abs_out_avg):
            if len(timeList) == 0:
                if x == 0:
                    timeList.append(i)
            else:
                if x == 0 and beforeIdx+1 != i:
                    if i - timeList[-1] >= 16000 * 4:
                        new = {"beg":np.floor((timeList[-1]/16000 + 0.1)*100)/100,'end':np.floor((i/16000 - 0.1) *100)/100}
                        reslut[pcm_name].append(new)
                    timeList.append(i)
            if x == 0:
                beforeIdx = i
    save_json(reslut,out_file_path)


def main():
    if "--audiolist" not in sys.argv[1] or "--outfile" not in sys.argv[2]:
        arg1 = sys.argv[1].replace("--audiolist=", "")
        arg2 = sys.argv[2].replace("--outfile=", "")
        detect_silence(arg1, arg2)
    else:
        args = arg_parse()
        detect_silence(args.audiolist, args.outfile)
  


if __name__ == "__main__":
    main()